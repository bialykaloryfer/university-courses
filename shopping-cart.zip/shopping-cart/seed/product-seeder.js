var User = require('../models/user');
var mongoose = require('mongoose');
const bcrypt = require('bcrypt');

mongoose.connect('mongodb://127.0.0.1:27017/shopping');

async function createAdmin() {
    var Admin = new User({
        email: "admin@admin.com",
        password: await bcrypt.hash("admin123", 10),
        admin: true
    });

    try {
        await Admin.save();
        console.log('Admin saved successfully');
    } catch (err) {
        console.error('Error saving admin:', err);
    } finally {
        mongoose.disconnect();
    }
}

createAdmin();
